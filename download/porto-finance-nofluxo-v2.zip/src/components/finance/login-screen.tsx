'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { cn } from '@/lib/utils'
import { Delete, Check, Lock } from 'lucide-react'

const PROFILES = [
  { name: 'Breno', color: '#16a34a', emoji: '👨' },
  { name: 'Kiki', color: '#db2777', emoji: '👩' },
  { name: 'Visita', color: '#0891b2', emoji: '👤' },
]

interface Props {
  onLogin: (name: string) => void
}

export function LoginScreen({ onLogin }: Props) {
  const [selectedProfile, setSelectedProfile] = useState<string | null>(null)
  const [pin, setPin] = useState('')
  const [error, setError] = useState(false)
  const [shake, setShake] = useState(false)

  // Reset PIN when changing profile
  function selectProfile(name: string) {
    setSelectedProfile(name)
    setPin('')
    setError(false)
  }

  function handleDigit(d: string) {
    if (pin.length >= 4) return
    const newPin = pin + d
    setPin(newPin)
    setError(false)
    
    // Auto-submit when 4 digits entered
    if (newPin.length === 4) {
      setTimeout(() => tryLogin(newPin), 200)
    }
  }

  function handleDelete() {
    setPin(pin.slice(0, -1))
    setError(false)
  }

  function tryLogin(pinToTest: string) {
    const stored = localStorage.getItem(`nofluxo_pin_${selectedProfile}`)
    const expectedPin = stored || '0000' // Default PIN is 0000
    
    if (pinToTest === expectedPin) {
      onLogin(selectedProfile!)
    } else {
      setError(true)
      setShake(true)
      setTimeout(() => {
        setShake(false)
        setPin('')
      }, 600)
    }
  }

  // Profile selection screen
  if (!selectedProfile) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-emerald-50 to-background dark:from-emerald-950/30 dark:to-background p-4">
        {/* Logo */}
        <div className="mb-8 text-center">
          <div className="inline-flex items-center justify-center mb-3">
            <img src="/logo-nofluxo.svg" alt="NoFluxo" className="h-20 w-20" />
          </div>
          <h1 className="text-3xl font-bold text-foreground">NoFluxo</h1>
          <p className="text-sm text-muted-foreground mt-1">Seu controle financeiro em fluxo</p>
        </div>

        {/* Profile selection */}
        <div className="w-full max-w-sm space-y-3">
          <p className="text-center text-sm text-muted-foreground mb-4">Quem está usando?</p>
          {PROFILES.map((p) => (
            <button
              key={p.name}
              onClick={() => selectProfile(p.name)}
              className="w-full flex items-center gap-3 p-4 rounded-xl border-2 border-border bg-background hover:border-primary hover:bg-muted/50 transition-all touch-manipulation group"
            >
              <div
                className="h-12 w-12 rounded-full flex items-center justify-center text-2xl flex-shrink-0"
                style={{ backgroundColor: p.color + '20' }}
              >
                {p.emoji}
              </div>
              <div className="flex-1 text-left">
                <div className="font-semibold text-foreground">{p.name}</div>
                <div className="text-xs text-muted-foreground">Toque para entrar</div>
              </div>
              <div
                className="h-2 w-2 rounded-full group-hover:scale-150 transition-transform"
                style={{ backgroundColor: p.color }}
              />
            </button>
          ))}
        </div>

        <p className="text-xs text-muted-foreground/60 mt-8">
          PIN padrão: 0000 (altere nas configurações)
        </p>
      </div>
    )
  }

  // PIN entry screen
  const profile = PROFILES.find((p) => p.name === selectedProfile)!

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-emerald-50 to-background dark:from-emerald-950/30 dark:to-background p-4">
      {/* Logo small */}
      <div className="mb-6 text-center">
        <img src="/logo-nofluxo.svg" alt="NoFluxo" className="h-16 w-16 mx-auto mb-2" />
        <h1 className="text-2xl font-bold text-foreground">NoFluxo</h1>
      </div>

      {/* Profile badge */}
      <div className="mb-8 flex flex-col items-center gap-2">
        <div
          className="h-20 w-20 rounded-full flex items-center justify-center text-4xl"
          style={{ backgroundColor: profile.color + '20' }}
        >
          {profile.emoji}
        </div>
        <p className="font-semibold text-foreground text-lg">{profile.name}</p>
        <p className="text-xs text-muted-foreground flex items-center gap-1">
          <Lock className="h-3 w-3" /> Digite seu PIN
        </p>
      </div>

      {/* PIN dots */}
      <div className={cn('flex gap-3 mb-8', shake && 'animate-shake')}>
        {[0, 1, 2, 3].map((i) => (
          <div
            key={i}
            className={cn(
              'h-4 w-4 rounded-full transition-all',
              error ? 'bg-rose-500' : pin.length > i ? 'bg-primary' : 'bg-muted border-2 border-border'
            )}
          />
        ))}
      </div>

      {/* Error message */}
      {error && (
        <p className="text-sm text-rose-500 mb-4">PIN incorreto. Tente novamente.</p>
      )}

      {/* Numeric keypad */}
      <div className="grid grid-cols-3 gap-3 max-w-xs w-full">
        {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((d) => (
          <button
            key={d}
            onClick={() => handleDigit(d)}
            className="h-16 rounded-xl bg-muted/50 hover:bg-muted active:scale-95 transition-all text-2xl font-semibold text-foreground touch-manipulation"
          >
            {d}
          </button>
        ))}
        <div /> {/* Empty */}
        <button
          onClick={() => pin.length === 4 && tryLogin(pin)}
          className="h-16 rounded-xl bg-primary/10 hover:bg-primary/20 active:scale-95 transition-all flex items-center justify-center text-primary touch-manipulation"
        >
          <Check className="h-6 w-6" />
        </button>
        <button
          onClick={handleDelete}
          className="h-16 rounded-xl bg-muted/50 hover:bg-muted active:scale-95 transition-all flex items-center justify-center text-muted-foreground touch-manipulation"
        >
          <Delete className="h-5 w-5" />
        </button>
      </div>

      {/* Back button */}
      <button
        onClick={() => setSelectedProfile(null)}
        className="mt-8 text-sm text-muted-foreground hover:text-foreground transition-colors"
      >
        ← Trocar perfil
      </button>
    </div>
  )
}
