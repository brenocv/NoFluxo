'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { cn } from '@/lib/utils'
import { Lock, User, Plus, ArrowLeft, Users, Folder } from 'lucide-react'

interface Profile {
  name: string
  password: string
}

interface Props {
  onLogin: (profileName: string, userName: string) => void
}

export function LoginScreen({ onLogin }: Props) {
  const [mode, setMode] = useState<'login' | 'register' | 'select-user' | 'select-workbook'>('login')
  const [profileName, setProfileName] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [error, setError] = useState('')
  const [selectedProfile, setSelectedProfile] = useState('')
  const [selectedUser, setSelectedUser] = useState('')
  const [newUser, setNewUser] = useState('')

  function getProfiles(): Profile[] {
    try {
      const stored = localStorage.getItem('nofluxo_profiles')
      return stored ? JSON.parse(stored) : []
    } catch { return [] }
  }

  function saveProfiles(profiles: Profile[]) {
    localStorage.setItem('nofluxo_profiles', JSON.stringify(profiles))
  }

  function getUsers(profileName: string): string[] {
    try {
      const stored = localStorage.getItem(`nofluxo_users_${profileName}`)
      return stored ? JSON.parse(stored) : []
    } catch { return [] }
  }

  function saveUsers(profileName: string, users: string[]) {
    localStorage.setItem(`nofluxo_users_${profileName}`, JSON.stringify(users))
  }

  function handleLogin() {
    if (!profileName.trim() || !password) {
      setError('Preencha perfil e senha')
      return
    }
    const profiles = getProfiles()
    const profile = profiles.find(p => p.name.toLowerCase() === profileName.trim().toLowerCase())
    if (!profile) {
      setError('Perfil não encontrado')
      return
    }
    if (profile.password !== password) {
      setError('Senha incorreta')
      return
    }
    setError('')
    setSelectedProfile(profile.name)
    
    // Check if there are users registered
    const users = getUsers(profile.name)
    if (users.length > 0) {
      setMode('select-user')
    } else {
      // No users yet — go to user creation
      setMode('select-user')
    }
  }

  function handleRegister() {
    if (!profileName.trim() || !password) {
      setError('Preencha perfil e senha')
      return
    }
    if (password !== confirmPassword) {
      setError('As senhas não coincidem')
      return
    }
    const profiles = getProfiles()
    if (profiles.find(p => p.name.toLowerCase() === profileName.trim().toLowerCase())) {
      setError('Este perfil já existe')
      return
    }
    profiles.push({ name: profileName.trim(), password })
    saveProfiles(profiles)
    setError('')
    setSelectedProfile(profileName.trim())
    setMode('select-user')
  }

  function handleSelectUser(name: string) {
    onLogin(selectedProfile, name)
  }

  function handleCreateUser() {
    if (!newUser.trim()) return
    const users = getUsers(selectedProfile)
    if (!users.includes(newUser.trim())) {
      users.push(newUser.trim())
      saveUsers(selectedProfile, users)
    }
    handleSelectUser(newUser.trim())
  }

  // ---- Register mode ----
  if (mode === 'register') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-emerald-50 to-background dark:from-emerald-950/30 dark:to-background p-4">
        <div className="mb-8 text-center">
          <img src="/logo-nofluxo.svg" alt="NoFluxo" className="h-20 w-20 mx-auto mb-3" />
          <h1 className="text-3xl font-bold text-foreground">NoFluxo</h1>
          <p className="text-sm text-muted-foreground mt-1">Criar novo perfil</p>
        </div>

        <div className="w-full max-w-sm space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="reg-profile">Nome do perfil</Label>
            <Input
              id="reg-profile"
              value={profileName}
              onChange={(e) => setProfileName(e.target.value)}
              placeholder="Ex.: Família, Empresa, Pessoal..."
              autoFocus
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="reg-pass">Senha</Label>
            <Input
              id="reg-pass"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Crie uma senha"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="reg-pass2">Confirmar senha</Label>
            <Input
              id="reg-pass2"
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Repita a senha"
              onKeyDown={(e) => e.key === 'Enter' && handleRegister()}
            />
          </div>
          {error && <p className="text-sm text-rose-500">{error}</p>}
          <Button onClick={handleRegister} className="w-full" disabled={!profileName.trim() || !password}>
            Criar perfil
          </Button>
          <button
            onClick={() => { setMode('login'); setError(''); setPassword(''); setConfirmPassword('') }}
            className="w-full text-sm text-muted-foreground hover:text-foreground flex items-center justify-center gap-1"
          >
            <ArrowLeft className="h-3 w-3" /> Voltar para login
          </button>
        </div>
      </div>
    )
  }

  // ---- Select user mode ----
  if (mode === 'select-user') {
    const users = getUsers(selectedProfile)
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-emerald-50 to-background dark:from-emerald-950/30 dark:to-background p-4">
        <div className="mb-6 text-center">
          <img src="/logo-nofluxo.svg" alt="NoFluxo" className="h-16 w-16 mx-auto mb-2" />
          <h1 className="text-2xl font-bold text-foreground">NoFluxo</h1>
          <p className="text-sm text-muted-foreground">Perfil: <strong>{selectedProfile}</strong></p>
        </div>

        <div className="w-full max-w-sm space-y-3">
          <p className="text-center text-sm text-muted-foreground mb-4">Quem está usando?</p>
          
          {users.map((u) => (
            <button
              key={u}
              onClick={() => handleSelectUser(u)}
              className="w-full flex items-center gap-3 p-4 rounded-xl border-2 border-border bg-background hover:border-primary hover:bg-muted/50 transition-all touch-manipulation"
            >
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                <User className="h-5 w-5 text-primary" />
              </div>
              <span className="font-medium text-foreground">{u}</span>
            </button>
          ))}

          {/* Create new user */}
          <div className="flex gap-2 pt-2">
            <Input
              value={newUser}
              onChange={(e) => setNewUser(e.target.value)}
              placeholder="Novo usuário..."
              onKeyDown={(e) => e.key === 'Enter' && handleCreateUser()}
              className="flex-1"
            />
            <Button onClick={handleCreateUser} disabled={!newUser.trim()} size="icon">
              <Plus className="h-4 w-4" />
            </Button>
          </div>

          {users.length === 0 && (
            <p className="text-xs text-muted-foreground text-center">
              Crie seu primeiro usuário para começar
            </p>
          )}

          <button
            onClick={() => { setMode('login'); setSelectedProfile(''); setError('') }}
            className="w-full text-sm text-muted-foreground hover:text-foreground flex items-center justify-center gap-1 pt-4"
          >
            <ArrowLeft className="h-3 w-3" /> Trocar perfil
          </button>
        </div>
      </div>
    )
  }

  // ---- Login mode (default) ----
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-emerald-50 to-background dark:from-emerald-950/30 dark:to-background p-4">
      <div className="mb-8 text-center">
        <img src="/logo-nofluxo.svg" alt="NoFluxo" className="h-20 w-20 mx-auto mb-3" />
        <h1 className="text-3xl font-bold text-foreground">NoFluxo</h1>
        <p className="text-sm text-muted-foreground mt-1">Seu controle financeiro em fluxo</p>
      </div>

      <div className="w-full max-w-sm space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="login-profile">Perfil</Label>
          <Input
            id="login-profile"
            value={profileName}
            onChange={(e) => setProfileName(e.target.value)}
            placeholder="Digite o nome do seu perfil"
            autoFocus
            onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="login-pass">Senha</Label>
          <Input
            id="login-pass"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Digite sua senha"
            onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
          />
        </div>
        {error && <p className="text-sm text-rose-500">{error}</p>}
        <Button onClick={handleLogin} className="w-full" disabled={!profileName.trim() || !password}>
          Entrar
        </Button>
        <div className="flex items-center gap-2 my-4">
          <div className="flex-1 h-px bg-border" />
          <span className="text-xs text-muted-foreground">ou</span>
          <div className="flex-1 h-px bg-border" />
        </div>
        <Button
          variant="outline"
          onClick={() => { setMode('register'); setError(''); setPassword(''); setConfirmPassword('') }}
          className="w-full"
        >
          <Plus className="h-4 w-4 mr-1" /> Criar novo perfil
        </Button>
      </div>

      <p className="text-xs text-muted-foreground/60 mt-8 text-center max-w-xs">
        Cada perfil é como um app separado. Dentro dele você pode criar usuários e planilhas.
      </p>
    </div>
  )
}
