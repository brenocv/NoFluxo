'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { cn } from '@/lib/utils'
import { Lock, User, Plus, ArrowLeft, Folder } from 'lucide-react'

interface Account {
  name: string
  password: string
}

interface Props {
  onLogin: (accountName: string, userName: string, workbookId?: string) => void
}

export function LoginScreen({ onLogin }: Props) {
  const [mode, setMode] = useState<'login' | 'register' | 'select-user' | 'create-workbook'>('login')
  const [accountName, setAccountName] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [workbookName, setWorkbookName] = useState('')
  const [error, setError] = useState('')
  const [selectedAccount, setSelectedAccount] = useState('')
  const [selectedUser, setSelectedUser] = useState('')
  const [newUser, setNewUser] = useState('')

  function getAccounts(): Account[] {
    try {
      const stored = localStorage.getItem('nofluxo_accounts')
      return stored ? JSON.parse(stored) : []
    } catch { return [] }
  }

  function saveAccounts(accounts: Account[]) {
    localStorage.setItem('nofluxo_accounts', JSON.stringify(accounts))
  }

  function getUsers(accountName: string): string[] {
    try {
      const stored = localStorage.getItem(`nofluxo_users_${accountName}`)
      return stored ? JSON.parse(stored) : []
    } catch { return [] }
  }

  function saveUsers(accountName: string, users: string[]) {
    localStorage.setItem(`nofluxo_users_${accountName}`, JSON.stringify(users))
  }

  async function createEmptyWorkbook(name: string) {
    try {
      const r = await fetch('/api/workbooks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name }),
      })
      if (!r.ok) return
      const data = await r.json()
      const wbId = data.workbook.id

      // Create ONLY the 3 top-level groups (no subgroups, no categories)
      const groups = [
        { key: 'despesas', name: 'Despesas', color: '#dc2626', type: 'EXPENSE', isDefault: true },
        { key: 'rendimentos', name: 'Receitas', color: '#16a34a', type: 'INCOME', isDefault: true },
        { key: 'reservas', name: 'Reservas', color: '#d97706', type: 'RESERVE', isDefault: true },
      ]
      for (const g of groups) {
        await fetch('/api/topgroups', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...g, workbookId: wbId }),
        })
      }

      // Set default config
      await fetch('/api/config', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: 'euroToBrl', value: '6', user: 'Sistema' }),
      })

      localStorage.setItem('nofluxo_workbook', wbId)
      return wbId
    } catch (e) {
      console.error('Erro ao criar planilha:', e)
    }
  }

  function handleLogin() {
    if (!accountName.trim() || !password) {
      setError('Preencha conta e senha')
      return
    }
    const accounts = getAccounts()
    const account = accounts.find(a => a.name.toLowerCase() === accountName.trim().toLowerCase())
    if (!account) {
      setError('Conta não encontrada')
      return
    }
    if (account.password !== password) {
      setError('Senha incorreta')
      return
    }
    setError('')
    setSelectedAccount(account.name)
    setMode('select-user')
  }

  async function handleRegister() {
    if (!accountName.trim() || !password) {
      setError('Preencha conta e senha')
      return
    }
    if (password !== confirmPassword) {
      setError('As senhas não coincidem')
      return
    }
    const accounts = getAccounts()
    if (accounts.find(a => a.name.toLowerCase() === accountName.trim().toLowerCase())) {
      setError('Esta conta já existe')
      return
    }
    accounts.push({ name: accountName.trim(), password })
    saveAccounts(accounts)
    setError('')
    setSelectedAccount(accountName.trim())
    setMode('select-user')
  }

  function handleSelectUser(name: string) {
    setSelectedUser(name)
    // Check if this account already has a workbook
    const existingWb = localStorage.getItem('nofluxo_workbook')
    if (existingWb) {
      onLogin(selectedAccount, name, existingWb)
    } else {
      // Ask for workbook name
      setMode('create-workbook')
    }
  }

  function handleCreateUser() {
    if (!newUser.trim()) return
    const users = getUsers(selectedAccount)
    if (!users.includes(newUser.trim())) {
      users.push(newUser.trim())
      saveUsers(selectedAccount, users)
    }
    handleSelectUser(newUser.trim())
  }

  async function handleCreateWorkbook() {
    if (!workbookName.trim()) return
    const wbId = await createEmptyWorkbook(workbookName.trim())
    onLogin(selectedAccount, selectedUser, wbId)
  }

  // ---- Create workbook mode (after user creation) ----
  if (mode === 'create-workbook') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-emerald-50 to-background dark:from-emerald-950/30 dark:to-background p-4">
        <div className="mb-8 text-center">
          <img src="/logo-nofluxo.svg" alt="NoFluxo" className="h-20 w-20 mx-auto mb-3" />
          <h1 className="text-3xl font-bold text-foreground">NoFluxo</h1>
          <p className="text-sm text-muted-foreground mt-1">Criar primeira planilha</p>
        </div>

        <div className="w-full max-w-sm space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="wb-name">Nome da planilha</Label>
            <Input
              id="wb-name"
              value={workbookName}
              onChange={(e) => setWorkbookName(e.target.value)}
              placeholder="Ex.: Porto 2026, Família 2026..."
              autoFocus
              onKeyDown={(e) => e.key === 'Enter' && handleCreateWorkbook()}
            />
            <p className="text-xs text-muted-foreground">
              Será criada com Despesas, Receitas e Reservas (vazia)
            </p>
          </div>
          {error && <p className="text-sm text-rose-500">{error}</p>}
          <Button onClick={handleCreateWorkbook} className="w-full" disabled={!workbookName.trim()}>
            Criar planilha
          </Button>
        </div>
      </div>
    )
  }

  // ---- Register mode ----
  if (mode === 'register') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-emerald-50 to-background dark:from-emerald-950/30 dark:to-background p-4">
        <div className="mb-8 text-center">
          <img src="/logo-nofluxo.svg" alt="NoFluxo" className="h-20 w-20 mx-auto mb-3" />
          <h1 className="text-3xl font-bold text-foreground">NoFluxo</h1>
          <p className="text-sm text-muted-foreground mt-1">Criar nova conta</p>
        </div>

        <div className="w-full max-w-sm space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="reg-account">Nome da conta</Label>
            <Input
              id="reg-account"
              value={accountName}
              onChange={(e) => setAccountName(e.target.value)}
              placeholder="Ex.: Família, Empresa, Pessoal..."
              autoFocus
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="reg-pass">Senha</Label>
            <Input
              id="reg-pass"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Crie uma senha"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="reg-pass2">Confirmar senha</Label>
            <Input
              id="reg-pass2"
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Repita a senha"
              onKeyDown={(e) => e.key === 'Enter' && handleRegister()}
            />
          </div>
          {error && <p className="text-sm text-rose-500">{error}</p>}
          <Button onClick={handleRegister} className="w-full" disabled={!accountName.trim() || !password}>
            Criar conta
          </Button>
          <button
            onClick={() => { setMode('login'); setError(''); setPassword(''); setConfirmPassword('') }}
            className="w-full text-sm text-muted-foreground hover:text-foreground flex items-center justify-center gap-1"
          >
            <ArrowLeft className="h-3 w-3" /> Voltar para login
          </button>
        </div>
      </div>
    )
  }

  // ---- Select user mode ----
  if (mode === 'select-user') {
    const users = getUsers(selectedAccount)
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-emerald-50 to-background dark:from-emerald-950/30 dark:to-background p-4">
        <div className="mb-6 text-center">
          <img src="/logo-nofluxo.svg" alt="NoFluxo" className="h-16 w-16 mx-auto mb-2" />
          <h1 className="text-2xl font-bold text-foreground">NoFluxo</h1>
          <p className="text-sm text-muted-foreground">Conta: <strong>{selectedAccount}</strong></p>
        </div>

        <div className="w-full max-w-sm space-y-3">
          <p className="text-center text-sm text-muted-foreground mb-4">Quem está usando?</p>
          
          {users.map((u) => (
            <button
              key={u}
              onClick={() => handleSelectUser(u)}
              className="w-full flex items-center gap-3 p-4 rounded-xl border-2 border-border bg-background hover:border-primary hover:bg-muted/50 transition-all touch-manipulation"
            >
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                <User className="h-5 w-5 text-primary" />
              </div>
              <span className="font-medium text-foreground">{u}</span>
            </button>
          ))}

          <div className="flex gap-2 pt-2">
            <Input
              value={newUser}
              onChange={(e) => setNewUser(e.target.value)}
              placeholder="Novo usuário..."
              onKeyDown={(e) => e.key === 'Enter' && handleCreateUser()}
              className="flex-1"
            />
            <Button onClick={handleCreateUser} disabled={!newUser.trim()} size="icon">
              <Plus className="h-4 w-4" />
            </Button>
          </div>

          {users.length === 0 && (
            <p className="text-xs text-muted-foreground text-center">
              Crie seu primeiro usuário para começar
            </p>
          )}

          <button
            onClick={() => { setMode('login'); setSelectedAccount(''); setError('') }}
            className="w-full text-sm text-muted-foreground hover:text-foreground flex items-center justify-center gap-1 pt-4"
          >
            <ArrowLeft className="h-3 w-3" /> Trocar conta
          </button>
        </div>
      </div>
    )
  }

  // ---- Login mode (default) ----
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-emerald-50 to-background dark:from-emerald-950/30 dark:to-background p-4">
      <div className="mb-8 text-center">
        <img src="/logo-nofluxo.svg" alt="NoFluxo" className="h-20 w-20 mx-auto mb-3" />
        <h1 className="text-3xl font-bold text-foreground">NoFluxo</h1>
        <p className="text-sm text-muted-foreground mt-1">Seu controle financeiro em fluxo</p>
      </div>

      <div className="w-full max-w-sm space-y-4">
        <div className="space-y-1.5">
          <Label htmlFor="login-account">Conta</Label>
          <Input
            id="login-account"
            value={accountName}
            onChange={(e) => setAccountName(e.target.value)}
            placeholder="Digite o nome da sua conta"
            autoFocus
            onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="login-pass">Senha</Label>
          <Input
            id="login-pass"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Digite sua senha"
            onKeyDown={(e) => e.key === 'Enter' && handleLogin()}
          />
        </div>
        {error && <p className="text-sm text-rose-500">{error}</p>}
        <Button onClick={handleLogin} className="w-full" disabled={!accountName.trim() || !password}>
          Entrar
        </Button>
        <div className="flex items-center gap-2 my-4">
          <div className="flex-1 h-px bg-border" />
          <span className="text-xs text-muted-foreground">ou</span>
          <div className="flex-1 h-px bg-border" />
        </div>
        <Button
          variant="outline"
          onClick={() => { setMode('register'); setError(''); setPassword(''); setConfirmPassword('') }}
          className="w-full"
        >
          <Plus className="h-4 w-4 mr-1" /> Criar nova conta
        </Button>
      </div>

      <p className="text-xs text-muted-foreground/60 mt-8 text-center max-w-xs">
        Cada conta é como um app separado. Dentro dela você pode criar usuários e planilhas.
      </p>
    </div>
  )
}
