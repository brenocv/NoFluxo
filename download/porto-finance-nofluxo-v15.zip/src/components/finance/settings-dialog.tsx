'use client'

import { useState, useEffect } from 'react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { cn } from '@/lib/utils'
import { Download, Plus, Trash2 } from 'lucide-react'

interface CustomCurrency {
  name: string
  symbol: string
  rate: number
}

interface Props {
  open: boolean
  onOpenChange: (open: boolean) => void
  euroRate: number
  onSaveEuroRate: (v: number) => Promise<void>
  onExportExcel?: () => void
  currencies?: CustomCurrency[]
  onSaveCurrencies?: (currencies: CustomCurrency[]) => Promise<void>
  onDeleteAccount?: () => void
  accountName?: string
}

export function SettingsDialog({
  open,
  onOpenChange,
  euroRate,
  onSaveEuroRate,
  onExportExcel,
  currencies = [],
  onSaveCurrencies,
  onDeleteAccount,
  accountName,
}: Props) {
  const [rate, setRate] = useState(String(euroRate))
  const [saving, setSaving] = useState(false)
  const [customCurrencies, setCustomCurrencies] = useState<CustomCurrency[]>(currencies)
  const [newCurrencyName, setNewCurrencyName] = useState('')
  const [newCurrencySymbol, setNewCurrencySymbol] = useState('')
  const [newCurrencyRate, setNewCurrencyRate] = useState('')

  useEffect(() => {
    setCustomCurrencies(currencies)
  }, [currencies])

  async function handleAddCurrency() {
    if (!newCurrencyName.trim() || !newCurrencyRate) return
    const rate = parseFloat(newCurrencyRate.replace(',', '.'))
    if (isNaN(rate) || rate <= 0) return
    const updated = [...customCurrencies, { name: newCurrencyName.trim(), symbol: newCurrencySymbol.trim() || newCurrencyName.trim(), rate }]
    setCustomCurrencies(updated)
    setNewCurrencyName('')
    setNewCurrencySymbol('')
    setNewCurrencyRate('')
    if (onSaveCurrencies) {
      setSaving(true)
      try { await onSaveCurrencies(updated) } finally { setSaving(false) }
    }
  }

  async function handleRemoveCurrency(idx: number) {
    const updated = customCurrencies.filter((_, i) => i !== idx)
    setCustomCurrencies(updated)
    if (onSaveCurrencies) {
      setSaving(true)
      try { await onSaveCurrencies(updated) } finally { setSaving(false) }
    }
  }

  async function handleUpdateCurrencyRate(idx: number, newRate: string) {
    const rate = parseFloat(newRate.replace(',', '.'))
    if (isNaN(rate) || rate <= 0) return
    const updated = [...customCurrencies]
    updated[idx] = { ...updated[idx], rate }
    setCustomCurrencies(updated)
    if (onSaveCurrencies) {
      setSaving(true)
      try { await onSaveCurrencies(updated) } finally { setSaving(false) }
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto" onOpenAutoFocus={(e) => e.preventDefault()}>
        <DialogHeader>
          <DialogTitle>Configurações</DialogTitle>
          <DialogDescription className="sr-only">
            Defina cotações de moedas e exporte a planilha.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-5 py-2">
          {/* Exchange rate (Euro) */}
          <div className="space-y-2">
            <Label htmlFor="rate">Cotação do Euro (em R$)</Label>
            <div className="flex gap-2">
              <Input
                id="rate"
                type="number"
                step="0.01"
                inputMode="decimal"
                value={rate}
                onChange={(e) => setRate(e.target.value)}
                className="flex-1"
              />
              <Button
                onClick={async () => {
                  const v = parseFloat(rate.replace(',', '.'))
                  if (isNaN(v) || v <= 0) return
                  setSaving(true)
                  try { await onSaveEuroRate(v) } finally { setSaving(false) }
                }}
                disabled={saving}
              >
                {saving ? 'Salvando…' : 'Salvar'}
              </Button>
            </div>
          </div>

          {/* Custom currencies */}
          {onSaveCurrencies && (
            <div className="space-y-3">
              <Label>Moedas personalizadas</Label>
              <p className="text-xs text-muted-foreground">
                Adicione moedas como Dólar, Libra, etc. A cotação é em relação ao Real (R$).
              </p>
              
              {customCurrencies.length > 0 && (
                <div className="space-y-2">
                  {customCurrencies.map((c, idx) => (
                    <div key={idx} className="flex items-center gap-2 p-2 rounded-md bg-muted/50">
                      <span className="text-sm font-medium flex-1">{c.symbol} {c.name}</span>
                      <Input
                        type="number"
                        step="0.01"
                        inputMode="decimal"
                        defaultValue={String(c.rate)}
                        onBlur={(e) => handleUpdateCurrencyRate(idx, e.target.value)}
                        className="w-24 h-8 text-xs"
                        title="Cotação em R$"
                      />
                      <span className="text-xs text-muted-foreground">R$</span>
                      <button
                        onClick={() => handleRemoveCurrency(idx)}
                        className="p-1 rounded hover:bg-destructive/10 hover:text-destructive"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              <div className="flex gap-2">
                <Input
                  value={newCurrencyName}
                  onChange={(e) => setNewCurrencyName(e.target.value)}
                  placeholder="Nome (ex: Dólar)"
                  className="flex-1"
                />
                <Input
                  value={newCurrencySymbol}
                  onChange={(e) => setNewCurrencySymbol(e.target.value)}
                  placeholder="$"
                  className="w-16"
                  title="Símbolo da moeda"
                />
                <Input
                  value={newCurrencyRate}
                  onChange={(e) => setNewCurrencyRate(e.target.value)}
                  placeholder="Valor em R$"
                  inputMode="decimal"
                  className="w-28"
                  title="Cotação em Real (ex: 5.50)"
                />
                <Button onClick={handleAddCurrency} disabled={!newCurrencyName.trim() || !newCurrencyRate} size="icon">
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}

          {/* Excel export */}
          {onExportExcel && (
            <div className="space-y-2">
              <Label>Exportar planilha</Label>
              <Button
                variant="outline"
                className="w-full justify-start gap-2"
                onClick={() => { onExportExcel(); onOpenChange(false) }}
              >
                <Download className="h-4 w-4" />
                Exportar Excel do ano atual
              </Button>
            </div>
          )}

          {/* Delete account */}
          {onDeleteAccount && (
            <div className="space-y-2 pt-4 border-t border-border">
              <Label>Conta: {accountName}</Label>
              <Button
                variant="outline"
                className="w-full justify-start gap-2 text-rose-500 border-rose-200 hover:bg-rose-50 dark:hover:bg-rose-950/30"
                onClick={() => {
                  if (confirm(`Apagar a conta "${accountName}" e todos os seus dados? Esta ação não pode ser desfeita.`)) {
                    onDeleteAccount()
                  }
                }}
              >
                <Trash2 className="h-4 w-4" />
                Apagar esta conta
              </Button>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button onClick={() => onOpenChange(false)}>Fechar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
