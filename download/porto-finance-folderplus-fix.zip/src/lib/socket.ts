'use client'

// Dummy socket - real-time sync disabled in production.
// App works with page refresh for sync.

export interface DummySocket {
  connected: boolean
  emit: (...args: any[]) => void
  on: (...args: any[]) => void
  off: (...args: any[]) => void
  disconnect: () => void
}

let socket: DummySocket | null = null

export function getSocket(): DummySocket {
  if (socket) return socket
  socket = {
    connected: false,
    emit: () => {},
    on: () => {},
    off: () => {},
    disconnect: () => {},
  }
  return socket
}

export function disconnectSocket() {
  if (socket) {
    socket.disconnect()
    socket = null
  }
}
